# test_bloc

This is Demo Flutter project.
with clear architecture and flutter_bloc state management.

## Getting Started

Usability commands:
flutter clean
flutter pub get
flutter packages upgrade
flutter packages pub run build_runner build

Add dependencies:
dependencies:
    flutter_bloc: ^8.1.1
    freezed: ^2.3.2

dev_dependencies:
    build_runner: ^2.3.3
